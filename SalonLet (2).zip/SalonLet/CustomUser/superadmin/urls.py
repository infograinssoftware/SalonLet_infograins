from django.urls import path
from .views import *
urlpatterns = [
    path('adminlogin/',adminlogin,name='login'),
    path('dashboard/',dashboard,name='dashboard'),
    path('Salonletuser',Salonletuser,name='Salonletuser'),
    path('vender/',vender,name='vender'),
    path('booking/',booking,name='booking'),
    path('home/',home,name='home'),
    path('Time/',Time,name='Time'),
    path('Notification/',Notification,name='Notification'),
    path('service/',service,name='service'),
    path('category/',category,name='category'),
    path('venderplane/',venderplane,name='venderplane'),
    path('profile/',profile,name='profile'),
    path('user_view',user_view,name='user_view'),
    path('user_view/<int:myid>',user_view,name='user_view'),
    path('status',changestatus,name='changestatus'),
    path('status/<int:myid>',changestatus,name='changestatus'),
    path('vendor_view/',vendor_view,name='vendor_view'),
    # path('checkboxes/',checkboxes,name='checkboxes'),
]