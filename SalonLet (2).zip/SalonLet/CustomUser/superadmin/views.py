from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
# Create your views here.
from authentication.models import User_Registration, Vendor_Registration
from users.models import User
# from .forms import VendorServiceForm
def adminlogin(request):
    email= 'm@g.com'
    password = '123'
    if request.method == 'POST':
        print(request.POST['email'],request.POST['password'])
        if email == request.POST['email'] and password == request.POST['password']:
            return redirect('/admin/')
    return render(request,'superadmin/login.html')



def home(request):
    return HttpResponse('hi')

def vender(request):
    userdata = Vendor_Registration.objects.all()
    return render(request ,'superadmin/user1.html',  {'userdata' : userdata})   

def booking(request):
    return render(request ,'superadmin/booking.html')    

def dashboard(request):
    userdata = User_Registration.objects.all()
    vendordata = Vendor_Registration.objects.all()
    return render(request ,'superadmin/dashboard.html',{'userdata' : len(userdata), 'vendordata' : len(vendordata)})       

def Time(request):
    return render(request ,'superadmin/time.html')    

def venderplane(request):
    return render(request ,'superadmin/venderplane.html')    

def Notification(request):
    return render(request ,'superadmin/Notification.html')    

def category(request):
    return render(request ,'superadmin/category.html')    

def service(request):
    return render(request ,'superadmin/service.html')    

def profile(request):
    return render(request ,'superadmin/profile.html')    

def user_view(request):
    userdata = User_Registration.objects.all()
    return render(request ,'superadmin/user_view.html', {'userdata' : userdata})     

def user_view(request,myid):
    u = get_object_or_404(User_Registration, pk = myid)
    return render(request ,'superadmin/user_view.html', {'userdata' : u})    
def Salonletuser(request):
    userdata = User_Registration.objects.all()
    return render(request ,'superadmin/user1.html',  {'userdata' : userdata})     

def vendor_view(request):
    return render(request ,'superadmin/viewvendor.html')         


def changestatus(request,myid):
    userdata = User_Registration.objects.all()
    uact = get_object_or_404(User, pk = myid)
    print(uact)
    print(uact.is_active)
    if uact.is_active:
        print(uact.is_active)
        uact.is_active = False
        print(uact.is_active)
        uact.save()
        uact = get_object_or_404(User, pk = myid)
        print(uact.is_active)
        return redirect('/super/Salonletuser')
    else:
        print("ram")
        uact.is_active = True
        print(uact.is_active)
        uact.save()
        uact = get_object_or_404(User, pk = myid)

        print(uact.is_active)
        return redirect('/super/Salonletuser')   

# def checkboxes(request):
#     form = VendorServiceForm()
#     if request.method == 'POST':
#         form = VendorServiceForm(request.POST)
#         if form.is_valid():
#             form.save()
#         return render(request, 'checkbox.html', {'form' : form})
#     return render(request, 'checkbox.html', {'form' : form})