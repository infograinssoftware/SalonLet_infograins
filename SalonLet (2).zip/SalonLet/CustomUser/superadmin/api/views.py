from rest_framework.generics import ListCreateAPIView 
from core.models import Service, ServiceClass
from .serializers import ServiceSerializer, ServiceClassSerializer

class ServiceAPI(ListCreateAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class ServiceClassAPI(ListCreateAPIView):
    queryset = ServiceClass.objects.all()
    serializer_class = ServiceClassSerializer
 