from rest_framework.generics import ListCreateAPIView 
from core.models import (
    VendorService, 
    BookingInvoice,
    BookingRequest,
    BookingResponse,
    Confirm_Booking
)

from .serializers import (
    VendorServiceSerializer,
    BookingInvoiceSerializer, 
    BookingRequestSerializer,
    BookingResponseSerializer,
    Confirm_BookingSerializer
)   
    
class VendorServiceAPI(ListCreateAPIView):
    queryset = VendorService.objects.all()
    serializer_class = VendorServiceSerializer

class BookingInvoiceAPI(ListCreateAPIView):
    queryset = BookingInvoice.objects.all()
    serializer_class = BookingInvoiceSerializer

class BookingRequestAPI(ListCreateAPIView):
    queryset = BookingRequest.objects.all()
    serializer_class = BookingRequestSerializer

class BookingResponseAPI(ListCreateAPIView):
    queryset = BookingResponse.objects.all()
    serializer_class = BookingResponseSerializer

class Confirm_BookingAPI(ListCreateAPIView):
    queryset = Confirm_Booking.objects.all()
    serializer_class = Confirm_BookingSerializer