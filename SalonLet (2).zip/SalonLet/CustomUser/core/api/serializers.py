from rest_framework import serializers
from core.models import (
    VendorService, 
    BookingInvoice,
    BookingRequest,
    BookingResponse,
    Confirm_Booking
)
class VendorServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = VendorService
        fields = '__all__'

class BookingInvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingInvoice
        fields = '__all__'    
        
class BookingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingRequest
        fields = '__all__'  

class BookingResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingResponse
        fields = '__all__'  

class Confirm_BookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Confirm_Booking
        fields = '__all__'  


