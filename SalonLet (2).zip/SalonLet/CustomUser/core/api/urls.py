from django.urls import path
from .views import (
    VendorServiceAPI,
    BookingInvoiceAPI,
    BookingRequestAPI,
    BookingResponseAPI,
    Confirm_BookingAPI
)
urlpatterns=[
    path('core/vendorservice_api',VendorServiceAPI.as_view(),name = 'vendorservice_api'),
    path('core/bookingInvoice_api',BookingInvoiceAPI.as_view(),name = 'bookingInvoice_api'),
    path('core/bookingrequest_api',BookingRequestAPI.as_view(),name = 'bookingrequest_api'),
    path('core/bookingresponse_api',BookingResponseAPI.as_view(),name = 'bookingresponse_api'),
    path('core/confirmbooking_api',Confirm_BookingAPI.as_view(),name = 'confirmbooking_api'),
]