from django.urls import path
from .views import (home, login_status, VendorSearch, selectservice, final_invoice, request_confirm, vendor_response, vendor_reject_response, response_list, my_bookings, vendor_bookings, waiting, serviceplace)
from django.contrib.auth.decorators import login_required
urlpatterns = [
    path('home/',home,name='home'),
    # path('filterdata/',filterdata,name='filterdata'),
    path('last/',login_status,name='last_login'),
    # path('vendorsearch/',VendorSearchs,name='vendorsearch'),
    path('vendorsearch/',VendorSearch,name='vendorsearch'),
    path('selectsearch/',selectservice,name='selectsearch'),
    # path('checktest/',checktest,name='checktest'),
    path('final_invoice/',login_required(final_invoice),name='final_invoice'),
    path('request_confirm/',login_required(request_confirm),name='request_confirm'),
    path('vendor_response',login_required(vendor_response),name='vendor_response'),
    path('vendor_response/<int:user_id>',login_required(vendor_response),name='vendor_response'),
    path('vendor_reject_response',login_required(vendor_reject_response),name='vendor_reject_response'),
    path('vendor_reject_response/<int:user_id>',login_required(vendor_reject_response),name='vendor_reject_response'),
    path('response_list/',login_required(response_list),name='response_list'),
    path('my_bookings/',login_required(my_bookings),name='my_bookings'),
    path('vendor_bookings/',login_required(vendor_bookings),name='vendor_bookings'),
    path('waiting/',login_required(waiting),name='waiting'),
    path('serviceplace/',login_required(serviceplace),name='serviceplace'),
]