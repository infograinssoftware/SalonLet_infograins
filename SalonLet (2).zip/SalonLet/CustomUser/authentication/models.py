from django.db import models
from users.models import User
from django.dispatch import receiver
from django.urls import reverse
from django_rest_passwordreset.signals import reset_password_token_created
from django.core.mail import send_mail

class User_Registration(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='media', default='media/dummy_profile.png')
    city = models.CharField(max_length=30, default=0, blank=True)
    state = models.CharField(max_length=30, default=0, blank=True)
    zipcode = models.IntegerField(default= 0, blank=True)
    country = models.CharField(max_length=30, default=0, blank=True)
    address = models.CharField(max_length=200,blank=True)
    latitude = models.FloatField(default=0)
    longitude = models.FloatField(default=0)
    referralCode = models.CharField(max_length=10, default=0, blank=True)
    def __str__(self):
        return self.user.email

class User_TemperoryModel(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='media', blank=True, null=False)
    city = models.CharField(max_length=30, default=0, blank=True)
    state = models.CharField(max_length=30, default=0, blank=True)
    zipcode = models.IntegerField(default= 0, blank=True)
    country = models.CharField(max_length=30, default=0, blank=True)
    address = models.CharField(max_length=200,blank=True)
    latitude = models.FloatField(default=0)
    longitude = models.FloatField(default=0)
    referralCode = models.CharField(max_length=10, default=0, blank=True)
    def __str__(self):
        return self.user.email

class User_OTP(models.Model):
    user = models.OneToOneField(User_TemperoryModel, on_delete=models.CASCADE)
    phone = models.CharField(max_length=17)
    otp_num = models.CharField(max_length=4)

    def __str__(self):
        return self.user.user.phone


class Vendor_Registration(models.Model):
    vuser = models.ForeignKey(User,on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='media', default='media/dummy_profile.png')
    city = models.CharField(max_length=30, default=0, blank=True)
    state = models.CharField(max_length=30, default=0, blank=True)
    zipcode = models.IntegerField(default= 0, blank=True)
    address = models.CharField(max_length=200,blank=True)
    country = models.CharField(max_length=30, default=0, blank=True)
    latitude = models.DecimalField(default=0, blank=True, decimal_places=4, max_digits= 6)
    longitude = models.DecimalField(default=0, blank=True, decimal_places=4, max_digits= 6)
    referralCode = models.CharField(max_length=10, default=0, blank=True)
    def __str__(self):
        return self.vuser.email

class Vendor_TemperoryModel(models.Model):
    vuser = models.ForeignKey(User,on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='media', blank=True, null=False)
    city = models.CharField(max_length=30, default=0, blank=True)
    state = models.CharField(max_length=30, default=0, blank=True)
    zipcode = models.IntegerField(default= 0, blank=True)
    country = models.CharField(max_length=30, default=0, blank=True)
    address = models.CharField(max_length=200,blank=True)
    latitude = models.DecimalField(default=0, blank=True, decimal_places=4, max_digits= 6)
    longitude = models.DecimalField(default=0, blank=True, decimal_places=4, max_digits= 6)
    referralCode = models.CharField(max_length=10, default=0, blank=True)
    def __str__(self):
        return self.vuser.email

class Vendor_OTP(models.Model):
    vuser = models.OneToOneField(Vendor_TemperoryModel, on_delete=models.CASCADE)
    phone = models.CharField(max_length=17)
    otp_num = models.CharField(max_length=4)

    def __str__(self):
        return self.vuser.vuser.phone


















#For Password reset through API
@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, *args, **kwargs):

    email_plaintext_message = "{}?token={}".format(reverse('password_reset:reset-password-request'), reset_password_token.key)

    send_mail(
        # title:
        "Password Reset for {title}".format(title="Login User SalonLet"),
        # message:
        email_plaintext_message,
        # from:
        "SalonLet",
        # "noreply@somehost.local",
        # to:
        [reset_password_token.user.email]
    )