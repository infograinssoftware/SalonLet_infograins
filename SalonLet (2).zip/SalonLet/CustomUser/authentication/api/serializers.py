from rest_framework import serializers
from authentication.models import User_Registration, User, User_OTP, User_TemperoryModel, Vendor_Registration, Vendor_OTP, Vendor_TemperoryModel
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.contrib.auth import authenticate, login
import random
from authentication.views import send_otp


    # def create(self, validated_data):
    #     order = Order.objects.get(pk=validated_data.pop('event'))
    #     instance = Equipment.objects.create(**validated_data)
    #     Assignment.objects.create(Order=order, Equipment=instance)
    #     return instance



# User Serializer
# class UserSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = User
#         fields = '__all__'
#     # def create(self, validated_data):
#     #     user = User.objects.create_user(validated_data['email'], validated_data['phone'], validated_data['password'])

#     #     return user 
# # Register Serializer
# class RegistrationSerializer(serializers.ModelSerializer):
#     user = UserSerializer()
#     class Meta:
#         model = Registration
#         fields = ('City','user')
        
     


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','first_name','last_name','email','phone','password']

        
class User_RegistrationSerializer(serializers.ModelSerializer):
    user = UserSerializer()
   
    def create(self, validated_data):
        user_dict = validated_data.pop('user')
        print("Hello")
        user_obj = User.objects.create_user(is_active=True,**user_dict)
        user = User_Registration.objects.create(user=user_obj, **validated_data)
        otp_gen = str(random.randint(1000,9999))
        otp_obj = User_OTP(user = user, phone = user_obj.phone, otp_num = otp_gen)
        otp_obj.save()
        if otp_obj is not None:
                send_otp(user_obj.phone, otp_gen)
        return user

    class Meta:
        model = User_Registration
        fields = ['id','user','zipcode','city', 'state', 'country', 'address', 'latitude', 'longitude']

class Edit_User_Profile_Serializer(serializers.ModelSerializer):
    user = UserSerializer()
    class Meta:
        model = User_Registration
        fields = ['user', 'profile_pic', 'address', 'state', 'zipcode', 'city', 'latitude', 'longitude']

class User_TemperoryModelSerializer(serializers.ModelSerializer):
    user = UserSerializer()
   
    def create(self, validated_data):
        user_dict = validated_data.pop('user')
        print("Hello")
        user_obj = User.objects.create_user(is_active=False,**user_dict)
        user = User_TemperoryModel.objects.create(user=user_obj, **validated_data)
        otp_gen = str(random.randint(1000,9999))
        otp_obj = User_OTP(user = user, phone = user_obj.phone, otp_num = otp_gen)
        otp_obj.save()
        if otp_obj is not None:
            send_otp(user_obj.phone, otp_gen)
        return user

    class Meta:
        model = User_TemperoryModel
        fields = ['id','user','zipcode','city', 'state', 'country', 'address', 'latitude', 'longitude']

    
class User_Loginserializer(serializers.ModelSerializer):
    token = serializers.CharField(
        allow_blank=True,
        read_only=True
    )
    class Meta:
        model = User
        fields =['id','email','password','token']

class User_OTPSerailizer(serializers.ModelSerializer):
    class Meta:
        model = User_OTP
        fields =['phone','otp_num']

class User_ResedOTPSerailizer(serializers.ModelSerializer):
    class Meta:
        model = User_OTP
        fields = ['phone','otp_num']
    # def validate(self, data):
    #     email = data.get('email', None)
    #     password = data.get('password', None)

    #     if not email :
    #         raise serializers.ValidationError("Please enter email to login.")

    #     user = User.objects.filter(
    #         Q(email=email)
    #     ).exclude(
    #         email__isnull=True
    #     ).exclude(
    #         email__iexact=''
    #     ).distinct()
       
    #     if user.exists() and user.count() == 1:
    #         user_obj = user.first()
    #         print(user_obj)
    #     else:
    #         raise serializers.ValidationError("This username/email is not valid.")

    #     if user_obj:
    #         if not user_obj.check_password(password):
    #             raise serializers.ValidationError("Invalid credentials.")
    #     print('hello')
    #     token, created = Token.objects.get_or_create(user=user_obj)
    #     data['token'] = token
    #     return data


    # def create(self, validated_data):
    #     choice_validated_data = validated_data.pop('user')
    #     print(choice_validated_data)
    #     question = Registration.objects.create(**validated_data)
    #     choice_set_serializer = self.fields['user']
    #     print(choice_set_serializer)
    #     choices = choice_set_serializer.create(choice_validated_data)
    #     return user
    #     extra_kwargs = {
    #         "Password": {"write_only": True},
    #         "Password_again": {"write_only": True}
    #     }
    # def validate_Password_again(self, value):
    #     data = self.get_initial()
    #     password = data.get('Password')
    #     if password != value:
    #         raise serializers.ValidationError("Passwords doesn't match.")
    #     return value
    # def validate_Email(self, value):
    #     data = self.get_initial()
    #     Email = data.get('Email')
    #     x = ClassAPI.objects.filter(Email = Email).exists()
    #     print(x)
    #     if x != False:
    #         raise serializers.ValidationError("Email already matched.")
    #     return value


         
# class Classserializer1(serializers.ModelSerializer):
#     class Meta:
#         model=LoginAPI
#         extra_kwargs = {
#             "Password": {"write_only": True},
#         }
#         fields= '__all__'
#     def validate(self, data):
#         email = data.get('Email', None)
#         password = data.get('Password', None)

#         if not email :
#             raise serializers.ValidationError("Please enter email to login.")

#         user = ClassAPI.objects.filter(
#             Q(Email=email)
#         ).exclude(
#             Email__isnull=True
#         ).exclude(
#             Email__iexact=''
#         ).distinct()

#         if user.exists() and user.count() == 1:
#             us00er_obj = user.first()
#         else:
#             raise serializers.ValidationError("This username/email is not valid.")

#         if user_obj:
#             if not user_obj.check_password(password):
#                 raise serializers.ValidationError("Invalid credentials.")

    
        
class Vendor_RegistrationSerializer(serializers.ModelSerializer):
    user = UserSerializer()
   
    def create(self, validated_data):
        user_dict = validated_data.pop('user')
        print("Hello")
        user_obj = User.objects.create_user(is_active=True,**user_dict)
        user = Vendor_Registration.objects.create(user=user_obj, **validated_data)
        otp_gen = str(random.randint(1000,9999))
        otp_obj = Vendor_OTP(user = user, phone = user_obj.phone, otp_num = otp_gen)
        otp_obj.save()
        if otp_obj is not None:
                send_otp(user_obj.phone, otp_gen)
        return user

    class Meta:
        model = Vendor_Registration
        fields = ['id','user','zipcode','city', 'state', 'country']


    

class Vendor_TemperoryModelSerializer(serializers.ModelSerializer):
    user = UserSerializer()
   
    def create(self, validated_data):
        user_dict = validated_data.pop('user')
        print("Hello")
        print(user_dict)
        user_obj = User.objects.create_user(is_active=False,**user_dict)
        user = Vendor_TemperoryModel.objects.create(user=user_obj, **validated_data)
        otp_gen = str(random.randint(1000,9999))
        otp_obj = Vendor_OTP(user = user, phone = user_obj.phone, otp_num = otp_gen)
        otp_obj.save()
        if otp_obj is not None:
            send_otp(user_obj.phone, otp_gen)
        return user

    class Meta:
        model = Vendor_TemperoryModel
        fields = ['id','user','zipcode','city', 'state', 'country']

    
class Vendor_Loginserializer(serializers.ModelSerializer):
    token = serializers.CharField(
        allow_blank=True,
        read_only=True
    )
    class Meta:
        model = User
        fields =['id','email','password','token']

class Vendor_OTPSerailizer(serializers.ModelSerializer):
    class Meta:
        model = Vendor_OTP
        fields =['phone','otp_num']

class Vendor_ResedOTPSerailizer(serializers.ModelSerializer):
    class Meta:
        model = Vendor_OTP
        fields = ['phone','otp_num']